#include "util_tap.h"
#include "util_sd.h"
#include <stdint.h>
#include <string.h>
#include <zx_emu/z80.h>
#include "pico/stdlib.h"
#include <ps2.h>
#include "zx_emu/zx_machine.h"
#include "screen_util.h"
#include <math.h>
#include "stdbool.h"
#include <VFS.h>
#include <ff.h>
#include "config.h"
//#define ZX_RAM_PAGE_SIZE 0x4000
#define BUFF_PAGE_SIZE 0x200

extern volatile z80 cpu;
extern uint8_t RAM[ZX_RAM_PAGE_SIZE*8]; //Реальная память куском 128Кб
//extern char sd_buffer[SD_BUFFER_SIZE];
extern char temp_msg[60];

#include "zx_emu/zx_machine.h"
#include "screen_util.h"



/*
typedef struct TapeBlock{
	uint16_t Size;
	uint8_t Flag;
	uint8_t DataType;
	char NAME[11];
	uint32_t FPos;
} __attribute__((packed)) TapeBlock;
*/

uint8_t tapBlocksCount=0;

uint8_t TapeStatus;
uint8_t SaveStatus;
uint8_t RomLoading;
FIL f;
int tfd =-1; //tape file descriptor
size_t bytesRead;
size_t bytesToRead;

static uint8_t tapePhase;
static uint64_t tapeStart;
static uint32_t tapePulseCount;
static uint16_t tapeBitPulseLen;   
static uint8_t tapeBitPulseCount;     
static uint32_t tapebufByteCount;
static uint32_t tapeBlockByteCount;
static uint16_t tapeHdrPulses;
static uint32_t tapeBlockLen;
static uint8_t* tape;
static uint8_t tapeEarBit;
static uint8_t tapeBitMask; 

uint8_t tapeCurrentBlock;
size_t tapeFileSize;
uint32_t tapeTotByteCount;

char tapeBHbuffer[20]; //tape block header buffer


uint8_t __not_in_flash_func(TAP_Read)(){
//uint8_t TAP_Read(){
    uint64_t tapeCurrent = cpu.cyc - tapeStart;
    //printf("Tape PHASE:%X\n",tapePhase);
    switch (tapePhase) {
    case TAPE_PHASE_SYNC:
        if (tapeCurrent > TAPE_SYNC_LEN) {
            tapeStart=cpu.cyc;
            tapeEarBit ^= 1;
            tapePulseCount++;
            if (tapePulseCount>tapeHdrPulses) {
                tapePulseCount=0;
                tapePhase=TAPE_PHASE_SYNC1;
            }
        }
        break;
    case TAPE_PHASE_SYNC1:
        if (tapeCurrent > TAPE_SYNC1_LEN) {
            tapeStart=cpu.cyc;
            tapeEarBit ^= 1;
            tapePhase=TAPE_PHASE_SYNC2;
        }
        break;
    case TAPE_PHASE_SYNC2:
        if (tapeCurrent > TAPE_SYNC2_LEN) {
            tapeStart=cpu.cyc;
            tapeEarBit ^= 1;
            if (tape[tapebufByteCount] & tapeBitMask) tapeBitPulseLen=TAPE_BIT1_PULSELEN; else tapeBitPulseLen=TAPE_BIT0_PULSELEN;            
            tapePhase=TAPE_PHASE_DATA;
        }
        break;
    case TAPE_PHASE_DATA:
        if (tapeCurrent > tapeBitPulseLen) {
            tapeStart=cpu.cyc;
            tapeEarBit ^= 1;
            tapeBitPulseCount++;
            if (tapeBitPulseCount==2) {
                tapeBitPulseCount=0;
                tapeBitMask = (tapeBitMask >>1 | tapeBitMask <<7);
                if (tapeBitMask==0x80) {
                    tapebufByteCount++;
					tapeBlockByteCount++;
					tapeTotByteCount++;
					//printf("BUF:%d BLOCK:%d TOTAL:%d\n",tapebufByteCount,tapeBlockByteCount,tapeTotByteCount);
					if(tapebufByteCount>=BUFF_PAGE_SIZE){
						//printf("Read next buffer\n");
						tfd = sd_read_file(&f,sd_buffer,BUFF_PAGE_SIZE,&bytesRead);
                    	//printf("bytesRead=%d\n",bytesRead);
		                if (tfd!=FR_OK){
							printf("Error read SD\n");
							sd_close_file(&f);
							tap_loader_active = false;
							tapebufByteCount=0;
							//im_z80_stop = false;       
							TapeStatus=TAPE_STOPPED;
							return false;
						}
						//im_z80_stop = false;
						tapebufByteCount=0;
					}
					if(tapeBlockByteCount==(tapeBlockLen-2)){
						tapeTotByteCount+=2;
						//printf("Wait next block: %d\n",tapeTotByteCount);
						tapebufByteCount=0;
                        tapePhase=TAPE_PHASE_PAUSE;
                        tapeEarBit=false;
						if (tapeTotByteCount == tapeFileSize){
							//printf("Full Read TAPE_STOPPED 2\n");
							TapeStatus=TAPE_STOPPED;
							TAP_Rewind();
							tap_loader_active = false;
							return false;
						}
                        break;
					}					
                }
                if (tape[tapebufByteCount] & tapeBitMask) tapeBitPulseLen=TAPE_BIT1_PULSELEN; else tapeBitPulseLen=TAPE_BIT0_PULSELEN;
            }
        }
        break;
    case TAPE_PHASE_PAUSE:
        if (tapeTotByteCount < tapeFileSize) {
            if (tapeCurrent > TAPE_BLK_PAUSELEN) {
				tapeCurrentBlock++;
				sd_seek_file(&f,tap_blocks[tapeCurrentBlock].FPos);
				tapeBlockLen=tap_blocks[tapeCurrentBlock].Size + 2;
				bytesToRead = tapeBlockLen<BUFF_PAGE_SIZE ? tapeBlockLen : BUFF_PAGE_SIZE;
				tfd = sd_read_file(&f,sd_buffer,bytesToRead,&bytesRead);
				if (tfd != FR_OK){
					printf("Error read SD\n");
					sd_close_file(&f);
					tap_loader_active = false;
					tapebufByteCount=0;
					TapeStatus=TAPE_STOPPED;
					return false;
				}
				//printf("Block:%d Seek:%d Length:%d Read:%d\n",tapeCurrentBlock,tap_blocks[tapeCurrentBlock].FPos,tapeBlockLen,bytesRead);
                tapeStart=cpu.cyc;
                tapePulseCount=0;
                tapePhase=TAPE_PHASE_SYNC;
                tapebufByteCount=2;
				tapeBlockByteCount=0;
				//printf("Flag:%X, DType:%X \n",tap_blocks[tapeCurrentBlock].Flag,tap_blocks[tapeCurrentBlock].DataType);
                if (tap_blocks[tapeCurrentBlock].Flag) tapeHdrPulses=TAPE_HDR_SHORT; else tapeHdrPulses=TAPE_HDR_LONG;
            }
        } else {
			//printf("Full Read TAPE_STOPPED\n");
			TapeStatus=TAPE_STOPPED;
			TAP_Rewind();
			tap_loader_active = false;
			break;
		}
        return false;
    } 
  
    return tapeEarBit;
}


void __not_in_flash_func(TAP_Play)(){
//void TAP_Play(){
    switch (TapeStatus) {
    case TAPE_STOPPED:
		//TAP_Load(activefilename);
       	tapePhase=TAPE_PHASE_SYNC;
       	tapePulseCount=0;
       	tapeEarBit=false;
       	tapeBitMask=0x80;
       	tapeBitPulseCount=0;
       	tapeBitPulseLen=TAPE_BIT0_PULSELEN;
       	tapeHdrPulses=TAPE_HDR_LONG;
		sd_seek_file(&f,tap_blocks[tapeCurrentBlock].FPos);
		tapeTotByteCount = tap_blocks[tapeCurrentBlock].FPos;
		tapeBlockLen=tap_blocks[tapeCurrentBlock].Size + 2;
		bytesToRead = tapeBlockLen<BUFF_PAGE_SIZE ? tapeBlockLen : BUFF_PAGE_SIZE;
		tfd = sd_read_file(&f,sd_buffer,bytesToRead,&bytesRead);
		if (tfd != FR_OK){sd_close_file(&f);break;}
		//printf("Block:%d Seek:%d Length:%d Read:%d\n",tapeCurrentBlock,tap_blocks[tapeCurrentBlock].FPos,tapeBlockLen,bytesRead);		
       	tapebufByteCount=2;
		tapeBlockByteCount=0;
       	tapeStart=cpu.cyc;
       	TapeStatus=TAPE_LOADING;
       	break;
    case TAPE_LOADING:
       	TapeStatus=TAPE_PAUSED;
       	break;
    case TAPE_PAUSED:
        tapeStart=cpu.cyc;
        TapeStatus=TAPE_LOADING;
		break;
    }
}


void Init(){
	TapeStatus = TAPE_STOPPED;
	SaveStatus = SAVE_STOPPED;
	RomLoading = false;
}

bool TAP_Load(char *file_name){
	
	printf("Tap Load begin\n");
    TapeStatus = TAPE_STOPPED;
	printf("Tap FN:%s\n",file_name);
	tfd = sd_open_file(&f,file_name,FA_READ);
    printf("sd_open_file=%d\n",tfd);
	if (tfd!=FR_OK){sd_close_file(&f);return false;}
   	tapeFileSize = sd_file_size(&f);
    printf(".TAP Filesize %u bytes\n", tapeFileSize);
	tapBlocksCount=0;
	tapebufByteCount=0;
	tapeBlockByteCount=0;
	tapeTotByteCount=0;
	while (tapeTotByteCount<=tapeFileSize){
		tfd = sd_read_file(&f,tapeBHbuffer,14,&bytesRead);
		if (tfd != FR_OK){sd_close_file(&f);return false;}
		//printf(" Readbuf:%d\n", bytesRead);
		//printf(" pos:%d\n", tapeTotByteCount);
		TapeBlock* block = (TapeBlock*) &tapeBHbuffer;
		tap_blocks[tapBlocksCount].Size = block->Size;
		//printf(" block:%d, size:%d ",tapBlocksCount,block->Size);
		memset(tap_blocks[tapBlocksCount].NAME, 0, sizeof(tap_blocks[tapBlocksCount].NAME));
		if (block->Flag==0){
			memcpy(tap_blocks[tapBlocksCount].NAME,block->NAME,10);
			//printf(" header:%s", block->NAME);
		}
		tap_blocks[tapBlocksCount].Flag = block->Flag;
		tap_blocks[tapBlocksCount].DataType = block->DataType;
		//printf(" flag:%d, datatype:%d \n", block->Flag,block->DataType);
		tap_blocks[tapBlocksCount].FPos=tapeTotByteCount;
		tapeTotByteCount+=block->Size+2;
		sd_seek_file(&f,tapeTotByteCount);
		tapBlocksCount++;
		if(tapeTotByteCount>=tapeFileSize){
			break;
		}
		if(tapBlocksCount==TAPE_BLK_SIZE){
			break;
		}
	}
	tapebufByteCount=0;
	tapeBlockByteCount=0;
	tapeTotByteCount=0;
	tapeCurrentBlock=0;
	sd_seek_file(&f,0);
	tape = &sd_buffer;

	/*for(uint8_t j=0;j<tapBlocksCount;j++){
		printf(" block:%d, size:%d \n",j,tap_blocks[j].Size);
	}*/


	
    return true;
}

void TAP_Rewind(){
	TapeStatus=TAPE_STOPPED;
	printf("Tape Rewind\n");
	tapebufByteCount=0;
	tapeBlockByteCount=0;
	tapeCurrentBlock=0;	
	tapeTotByteCount=0;
};

void TAP_NextBlock(){
	printf("Tape NextBlock\n");
	tapeCurrentBlock++;
	if ((tapeCurrentBlock>=0)&&(tapeCurrentBlock<tapBlocksCount)){
		TapeStatus=TAPE_STOPPED;
		TAP_Play();
	}
	if (tapeCurrentBlock>tapBlocksCount){
		TAP_Rewind();
	}

};

void TAP_PrevBlock(){
	printf("Tape PrevBlock\n");
	tapeCurrentBlock--;
	if ((tapeCurrentBlock>=0)&&(tapeCurrentBlock<tapBlocksCount)){
		TapeStatus=TAPE_STOPPED;
		TAP_Play();
	}
	if (tapeCurrentBlock>tapBlocksCount){
		TAP_Rewind();
	}
};


/*

#define coef           (0.990) //0.993->
#define PILOT_TONE     (2168*coef) //2168
#define PILOT_SYNC_HI  (667*coef)  //667
#define PILOT_SYNC_LOW (735*coef)  //735
#define LOG_ONE        (1710*coef) //1710
#define LOG_ZERO       (855*coef)  //855

	#define PILOT_TONE     (2168) //2168
	#define PILOT_SYNC_HI  (667)  //667
	#define PILOT_SYNC_LOW (735)  //735
	#define LOG_ONE        (1710) //1710
	#define LOG_ZERO       (855)  //855
*/

bool LoadScreenFromTap(char *file_name){

	bool screen_found = false;
	uint8_t* bufferOut;

	memset(sd_buffer, 0, sizeof(sd_buffer));

	for(uint8_t i=0;i<TAPE_BLK_SIZE;i++){
		tap_blocks[i].DataType=0;
		tap_blocks[i].Flag=0;
		tap_blocks[i].FPos=0;
		tap_blocks[i].Size=0;
		tap_blocks[i].NAME[0]=0;
	}
	

	tfd = sd_open_file(&f,file_name,FA_READ);
    printf("sd_open_file=%d\n",tfd);
	if (tfd!=FR_OK){sd_close_file(&f);return false;}
   	tapeFileSize = sd_file_size(&f);
    printf(".TAP Filesize %u bytes\n", tapeFileSize);
	tapBlocksCount=0;
	tapebufByteCount=0;
	tapeBlockByteCount=0;
	tapeTotByteCount=0;
	while (tapeTotByteCount<=tapeFileSize){
		tfd = sd_read_file(&f,tapeBHbuffer,14,&bytesRead);
		if (tfd != FR_OK){sd_close_file(&f);return false;}
		//printf(" Readbuf:%d\n", bytesRead);
		//printf(" pos:%d\n", tapeTotByteCount);
		TapeBlock* block = (TapeBlock*) &tapeBHbuffer;
		tap_blocks[tapBlocksCount].Size = block->Size;
		//printf(" block:%d, size:%d ",tapBlocksCount,block->Size);
		memset(tap_blocks[tapBlocksCount].NAME, 0, sizeof(tap_blocks[tapBlocksCount].NAME));
		if (block->Flag==0){
			memcpy(tap_blocks[tapBlocksCount].NAME,block->NAME,10);
			//printf(" header:%s", block->NAME);
		}
		tap_blocks[tapBlocksCount].Flag = block->Flag;
		tap_blocks[tapBlocksCount].DataType = block->DataType;
		//printf(" flag:%d, datatype:%d \n", block->Flag,block->DataType);
		tap_blocks[tapBlocksCount].FPos=tapeTotByteCount;
		tapeTotByteCount+=block->Size+2;
		sd_seek_file(&f,tapeTotByteCount);
		tapBlocksCount++;
		if(tapeTotByteCount>=tapeFileSize){
			break;
		}
		if(tapBlocksCount==TAPE_BLK_SIZE){
			break;
		}
	}
	tapebufByteCount=0;
	tapeBlockByteCount=0;
	tapeTotByteCount=0;
	tapeCurrentBlock=0;
	sd_seek_file(&f,0);

	for (int8_t i=0;i<tapBlocksCount;i++){
		if (tap_blocks[i].Flag>0){
			if((tap_blocks[i].Size>=0x1AFE)&&(tap_blocks[i].Size<=0x1B02)){
				sd_seek_file(&f,tap_blocks[i].FPos);
				bufferOut = (SD_BUFFER_SIZE>0x2000) ? &sd_buffer[0x2000] : &RAM[5*ZX_RAM_PAGE_SIZE];
				memset(sd_buffer, 0, sizeof(sd_buffer));
				tfd = sd_read_file(&f,bufferOut,tap_blocks[i].Size,&bytesRead);
	        	printf("bytesRead=%d\n",bytesRead);
	        	if (tfd!=FR_OK){sd_close_file(&f);return false;}
		        ShowScreenshot(bufferOut);
				screen_found = true;
				break;
			}
		}			
	}

	if (!screen_found){
		draw_text_len(18+FONT_W*14,16,"File contents:",COLOR_TEXT,COLOR_BACKGOUND,14);
		for (uint8_t i = 0; i < 22; i++){
			if (tap_blocks[i].Size>0){
				if (tap_blocks[i].Flag==0){
					memset(temp_msg, 0, sizeof(temp_msg));
					sprintf(temp_msg,"%s",tap_blocks[i].NAME);
					draw_text_len(18+FONT_W*15,24+FONT_H*(i+1),temp_msg,COLOR_TEXT,COLOR_BACKGOUND,10);
				} else{
					memset(temp_msg, 0, sizeof(temp_msg));
					sprintf(temp_msg," %dKb",(tap_blocks[i].Size/1024));
					draw_text_len(18+FONT_W*25,24+FONT_H*(i),temp_msg,COLOR_TEXT,COLOR_BACKGOUND,10);
				}
			//	draw_text_len(18+FONT_W*15,24+FONT_H*i,temp_msg,COLOR_TEXT,COLOR_BACKGOUND,10);
			}
		}
	}
    memset(temp_msg, 0, sizeof(temp_msg));
	sprintf(temp_msg,"Type:.TAP");
	draw_text_len(18+FONT_W*14,208, temp_msg,COLOR_TEXT,COLOR_BACKGOUND,22);
	memset(temp_msg, 0, sizeof(temp_msg));
	sprintf(temp_msg,"FSize: %dKb",sd_file_size(&f)/1024);
	draw_text_len(18+FONT_W*14,216, temp_msg,COLOR_TEXT,COLOR_BACKGOUND,22);
	memset(temp_msg, 0, sizeof(temp_msg));
	//strncpy(file_name,"A:/",3);
	//strncpy(temp_msg,file_name,22);
	//draw_text_len(18+FONT_W*14,224, temp_msg,COLOR_TEXT,COLOR_BACKGOUND,22);

	sd_close_file(&f);
	printf("\nAll loaded\n");
	memset(temp_msg, 0, sizeof(temp_msg));
    return true;
}
//==================================================================================
	// меню tape test
	const char __in_flash() *menu_tape[6]={
	//char*  menu_setup[6]={	
	" 1           ",
	" 2           ",
	" 3           ",
	" 4           ",
	" 5           ",
	" Exit        ",
	
};

   //     snprintf(str, sizeof str, "%d",(int) (clock_get_hz(clk_sys)/1000000));
//		draw_text_len(40+FONT_W+2,20+FONT_H*2,str,CL_GREEN,CL_BLACK,3);

	void tape_load(void)
	{
#define X 20 + FONT_W + 2
#define Y 50 + FONT_H * 2
		MenuBox_lite(X, Y, 30, 6, "TAPE LOADER", 1);
		char str[32];
		snprintf(str, sizeof str, "PC %#X BANK:%#d", (uint16_t)(cpu.pc), zx_RAM_bank_active);
		draw_text(X, Y + 10, str, CL_GRAY, CL_BLACK);
		uint16_t num16 = (cpu.d << 8) | cpu.e; // длина
		snprintf(str, sizeof str, "Adr: %#x Len:%#x/%d", (uint16_t)(cpu.ix), (num16), (num16));
		draw_text(X, Y + 20, str, CL_GREEN, CL_BLACK);
		snprintf(str, sizeof str, "Reg A:%#X Flag C:%o", (uint8_t)(cpu.a), (uint8_t)(cpu.cf));
		draw_text(X, Y + 30, str, CL_GREEN, CL_BLACK);

        tfd = sd_open_file(&f, activefilename, FA_READ);
	//	tfd = sd_open_file(&f, "0:/TEST_TAP.TAP ", FA_READ);
		while (1)
		{

			decode_key();
			if (kb_st_ps2.u[1] & KB_U1_ESC) // ESC
			{

				if (cpu.a == 0) // то заголовок
				{
					// чтение заголовка
					char TapeHeader[20];

					tfd = sd_read_file(&f, TapeHeader, 20, &bytesRead);

					uint16_t adr_s = cpu.ix;			   // адрес загрузки в spectrum
					uint16_t len_s = (cpu.d << 8) | cpu.e; // длина
														   // 0..1 Длина блока
					// 2    Флаговый байт (0 для заголовка, 255 для тела файла)
					// 3..xx  Эти байты представляют собой данные самого блока - либо заголовка, либо основного текста
					//  last  Байт контрольной суммы
					//  TapeHeader[0]
					//  TapeHeader[1] // длина блока заголовок 19 байт
					//  TapeHeader[2] // Флаговый байт (0 для заголовка, 255 для тела файла)

					// cpu.write_byte(NULL,adr_s+0,TapeHeader[3]); //данные блока
					uint16_t lenBlk = (TapeHeader[1] << 8) | TapeHeader[0]; // длина блока
					uint8_t flagA = TapeHeader[2];
					snprintf(str, sizeof str, "flag:%o len:%#x/%d",(uint8_t) flagA, lenBlk, lenBlk);
					draw_text(X, Y + 40, str, CL_RED, CL_BLACK);

					uint16_t lenDat = (TapeHeader[15] << 8) | TapeHeader[14]; // длина данных

					snprintf(str, sizeof str, "len: %#x/%d", (uint16_t)(lenDat), (lenDat));
					draw_text(X, Y + 50, str, CL_LT_GREEN, CL_BLACK);

					for (uint8_t i = 0; i < 16; i++)
					{
						cpu.write_byte(NULL, adr_s + i, TapeHeader[i + 3]);
					}

					cpu.cf = 1;		 // ошибка
					cpu.pc = 0x0555; // ret c9 там

					return;
				}
                if (cpu.a == 0xff) // то данные
				{


					

					uint16_t adr_s = cpu.ix;			   // адрес загрузки в spectrum
					uint16_t len_s = (cpu.d << 8) | cpu.e; // длина
														   // 0..1 Длина блока
					// 2    Флаговый байт (0 для заголовка, 255 для тела файла)
					// 3..xx  Эти байты представляют собой данные самого блока - либо заголовка, либо основного текста
					//  last  Байт контрольной суммы
					//  TapeHeader[0]
					//  TapeHeader[1] // длина блока заголовок 19 байт
					//  TapeHeader[2] // Флаговый байт (0 для заголовка, 255 для тела файла)

                    sd_seek_file(&f,24);// смещаемся в файле на 24 байт 
					
					tfd = sd_read_file(&f, sd_buffer, len_s, &bytesRead);

				    uint16_t lenBlk = (sd_buffer[1] << 8) | sd_buffer[0]; // длина блока
					//uint16_t lenBlk = 0x14a8;
					uint8_t flagA = sd_buffer[2];
					snprintf(str, sizeof str, "flag:%x len:%#x/%d",(uint8_t) flagA, lenBlk, lenBlk);
					draw_text(X, Y + 40, str, CL_LT_BLUE, CL_BLACK);

					//uint16_t lenDat = (TapeHeader[15] << 8) | TapeHeader[14]; // длина данных

					//snprintf(str, sizeof str, "len: %#x/%d", (uint16_t)(lenDat), (lenDat));
					//draw_text(X, Y + 50, str, CL_LT_GREEN, CL_BLACK);

					for (uint16_t i = 0; i < len_s; i++)
					{
						cpu.write_byte(NULL, adr_s + i, sd_buffer[i]);
					}

					cpu.cf = 1;		 // ошибка
					cpu.pc = 0x0555; // ret c9 там

					return;
				}



			}
		}
	}

 /* 
 while(1){
  
	decode_key() ;
if (kb_st_ps2.u[1]&KB_U1_ESC)   // ESC
      {
		//MessageBox("TAPE  END","",CL_WHITE,CL_GREEN,1);




        uint16_t adr_s = cpu.ix;
		uint16_t len_s = (cpu.d<<8) | cpu.e;

		cpu.write_byte(NULL,adr_s+0,0); //basic

		cpu.write_byte(NULL,adr_s+1,'T'); //имя файла
        cpu.write_byte(NULL,adr_s+2,'e'); //имя файла
        cpu.write_byte(NULL,adr_s+3,'s'); //имя файла
        cpu.write_byte(NULL,adr_s+4,'t'); //имя файла
		cpu.write_byte(NULL,adr_s+5,'_'); //имя файла
        cpu.write_byte(NULL,adr_s+6,'T'); //имя файла
        cpu.write_byte(NULL,adr_s+7,'A'); //имя файла
        cpu.write_byte(NULL,adr_s+8,'P'); //имя файла
        cpu.write_byte(NULL,adr_s+9,'E'); //имя файла
        cpu.write_byte(NULL,adr_s+10,'7'); //имя файла

		cpu.write_byte(NULL,adr_s+11,12); //L длина
        cpu.write_byte(NULL,adr_s+12,0); //H длина

		cpu.write_byte(NULL,adr_s+13,1); //L номер строки автозапуска
        cpu.write_byte(NULL,adr_s+14,0); //H 

		cpu.write_byte(NULL,adr_s+15,12); //L длина basic программы
        cpu.write_byte(NULL,adr_s+16,1); //H 



      cpu.cf = 1; // ошибка
	  cpu.pc = 0x0555 ; // ret c9 там 
//cpu.prev_opcode = 0xc9; // ret c9 там





        return 0xff;
      }
 


 
 }

} */