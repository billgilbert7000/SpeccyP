#include "g_config.h"




int	null_printf(const char *str, ...){return 0;};

void g_delay_ms(uint delay)
{
    sleep_ms(delay);
    
};






