#pragma once
#include "hardware/pio.h"

#define pio_SPI_TFT pio0
#define sm_SPI_TFT 0

#define pio_SPI_TFT_conv pio0
#define sm_SPI_TFT_conv 1

void init_TFT();

