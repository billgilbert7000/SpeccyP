#ifndef BOARD_H
#define BOARD_H

// Nothing valuable here

#endif
