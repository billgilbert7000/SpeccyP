#include "fdi_light.h"
#include <string.h>

#include "ff.h"

// Вспомогательная функция: прочитать uint16_t из little-endian
static uint16_t read_le16(const uint8_t *p) {
    return p[0] | (p[1] << 8);
}

// Вспомогательная функция: прочитать uint32_t из little-endian
static uint32_t read_le32(const uint8_t *p) {
    return p[0] | (p[1] << 8) | (p[2] << 16) | (p[3] << 24);
}

fdi_light_result_t fdi_light_open(fdi_light_ctx_t *ctx, const char *filename) {
    if (!ctx || !filename) return FDI_LIGHT_ERR_INVALID_PARAMETERS;
    
   // memset(ctx, 0, sizeof(fdi_light_ctx_t));
    
    // Открываем файл через пользовательские функции
    ctx->file_handle = ctx->file_io.open(filename);
    if (!ctx->file_handle) return FDI_LIGHT_ERR_FILE_ERROR;
    
    // Читаем заголовок (первые 14 байт)
    uint8_t header[14];
    if (!ctx->file_io.read(ctx->file_handle, header, 14)) {
        ctx->file_io.close(ctx->file_handle);
        return FDI_LIGHT_ERR_FILE_ERROR;
    }
    
    // Проверка сигнатуры
    if (header[0] != 'F' || header[1] != 'D' || header[2] != 'I') {
        ctx->file_io.close(ctx->file_handle);
        return FDI_LIGHT_ERR_INVALID_SIGNATURE;
    }
    
    // Парсим заголовок
    ctx->cylinders = read_le16(&header[4]);
    ctx->heads = read_le16(&header[6]);
    ctx->text_offset = read_le16(&header[8]);
    ctx->data_offset = read_le16(&header[10]);
    uint16_t extra_len = read_le16(&header[12]);
    
    // Проверка параметров
    if (ctx->cylinders == 0 || ctx->cylinders > 255 || 
        ctx->heads == 0 || ctx->heads > 2) {
        ctx->file_io.close(ctx->file_handle);
        return FDI_LIGHT_ERR_INVALID_PARAMETERS;
    }
    
    // Вычисляем позицию заголовков треков (после заголовка и доп. инфо)
    ctx->tracks_info_pos = 14 + extra_len;
    
    // Читаем комментарий (если нужно)
    if (ctx->text_offset > 0) {
        ctx->file_io.seek(ctx->file_handle, ctx->text_offset);
        ctx->file_io.read(ctx->file_handle, (uint8_t*)ctx->comment, sizeof(ctx->comment)-1);
        ctx->comment[sizeof(ctx->comment)-1] = '\0';
    }
    
    ctx->valid = true;
    ctx->track_loaded = false;
    
    return FDI_LIGHT_OK;
}

void fdi_light_close(fdi_light_ctx_t *ctx) {
    if (ctx && ctx->file_handle) {
        ctx->file_io.close(ctx->file_handle);
        ctx->file_handle = NULL;
    }
    ctx->valid = false;
}

fdi_light_result_t fdi_light_load_track(fdi_light_ctx_t *ctx, uint8_t cylinder, uint8_t head) {
    if (!ctx || !ctx->valid || !ctx->file_handle) {
        return FDI_LIGHT_ERR_INVALID_PARAMETERS;
    }
    
    if (cylinder >= ctx->cylinders || head >= ctx->heads) {
        return FDI_LIGHT_ERR_TRACK_NOT_FOUND;
    }
    
    // Вычисляем индекс трека
    uint32_t track_index = cylinder * ctx->heads + head;
    
    // Ищем нужный трек в заголовках
    // Нам нужно пропустить все предыдущие треки
    uint32_t current_pos = ctx->tracks_info_pos;
    
    for (uint32_t i = 0; i <= track_index; i++) {
        // Переходим к заголовку i-го трека
        ctx->file_io.seek(ctx->file_handle, current_pos);
        
        // Читаем заголовок трека (первые 7 байт)
        uint8_t track_hdr[7];
        ctx->file_io.read(ctx->file_handle, track_hdr, 7);
        
        uint32_t track_offset = read_le32(track_hdr);
        uint8_t sectors_per_track = track_hdr[6];
        
        if (i == track_index) {
            // Это нужный нам трек - загружаем его
            ctx->current_track.cylinder = cylinder;
            ctx->current_track.head = head;
            ctx->current_track.sectors = sectors_per_track;
            ctx->current_track.track_offset = track_offset;
            ctx->current_track.track_data_pos = ctx->data_offset + track_offset;
            
            // Читаем информацию о секторах
            for (uint8_t s = 0; s < sectors_per_track; s++) {
                uint8_t sec_info[7];
                ctx->file_io.read(ctx->file_handle, sec_info, 7);
                
                fdi_sector_light_t *sec = &ctx->current_track.sectors_info[s];
                sec->c = sec_info[0];
                sec->h = sec_info[1];
                sec->r = sec_info[2];
                sec->n = sec_info[3];
                sec->flags = sec_info[4];
                sec->data_offset = read_le16(&sec_info[5]);
                sec->data_size = fdi_sector_size(sec->n);
            }
            
            ctx->track_loaded = true;
            ctx->current_track_idx = track_index;
            return FDI_LIGHT_OK;
        } else {
            // Пропускаем информацию о секторах этого трека
            uint32_t skip = sectors_per_track * 7;
            current_pos = current_pos + 7 + skip;
        }
    }
    
    return FDI_LIGHT_ERR_TRACK_NOT_FOUND;
}

fdi_track_light_t* fdi_light_get_current_track(fdi_light_ctx_t *ctx) {
    if (!ctx || !ctx->track_loaded) return NULL;
    return &ctx->current_track;
}

fdi_sector_light_t* fdi_light_get_sector(fdi_light_ctx_t *ctx, uint8_t sector_r) {
    if (!ctx || !ctx->track_loaded) return NULL;
    
    for (uint8_t i = 0; i < ctx->current_track.sectors; i++) {
        if (ctx->current_track.sectors_info[i].r == sector_r) {
            return &ctx->current_track.sectors_info[i];
        }
    }
    
    return NULL;
}

// Функция для чтения данных сектора
bool fdi_light_read_sector_data(fdi_light_ctx_t *ctx, fdi_sector_light_t *sec, uint8_t *buffer) {
    if (!ctx || !ctx->file_handle || !sec || !buffer) return false;
    if (!sec->data_size) return false;
    
    uint32_t sector_pos = ctx->current_track.track_data_pos + sec->data_offset;
    ctx->file_io.seek(ctx->file_handle, sector_pos);
    return ctx->file_io.read(ctx->file_handle, buffer, sec->data_size);
}