#ifndef FDI_LIGHT_H
#define FDI_LIGHT_H

#include <stdint.h>
#include <stdbool.h>
#include "ff.h"

#define FDI_MAX_SEC_PER_TRACK 16

// Структура заголовка FDI (по спецификации)
#pragma pack(push, 1)
typedef struct {
    uint8_t signature[3];        // +00 (3) 'FDI'
    uint8_t write_protect;        // +03 (1) 0 - write enabled, 1 - write disabled
    uint16_t cylinders;           // +04 (2) число цилиндров (little-endian)
    uint16_t heads;               // +06 (2) число поверхностей (little-endian)
    uint16_t text_offset;         // +08 (2) смещение комментария (little-endian)
    uint16_t data_offset;         // +0A (2) смещение данных (little-endian)
    uint16_t extra_len;           // +0C (2) длина доп. информации
} fdi_header_t;
#pragma pack(pop)

// Информация о секторе (для одного сектора)
typedef struct {
    uint8_t c;           // цилиндр
    uint8_t h;           // головка
    uint8_t r;           // номер сектора
    uint8_t n;           // размер (0=128,1=256,2=512,3=1024)
    uint8_t flags;       // флаги
    uint16_t data_offset;// смещение данных сектора относительно начала трека
    uint16_t data_size;  // размер данных в байтах (вычисляется из n)
} fdi_sector_light_t;

// Информация о треке (для одного трека)
typedef struct {
    uint8_t cylinder;        // номер цилиндра
    uint8_t head;            // номер головки
    uint8_t sectors;         // количество секторов
    uint32_t track_offset;   // смещение данных трека относительно data_offset
    uint32_t track_data_pos; // абсолютная позиция данных трека в файле
    fdi_sector_light_t sectors_info[FDI_MAX_SEC_PER_TRACK]; // до 64 секторов
} fdi_track_light_t;

// Основной контекст (минимальный)
typedef struct {
    // Геометрия диска
    uint16_t cylinders;
    uint8_t heads;
    uint16_t data_offset;    // смещение данных в файле
    uint16_t text_offset;    // смещение комментария
    
    // Позиции в файле
    uint32_t tracks_info_pos; // позиция начала заголовков треков
    uint32_t current_track_idx; // индекс текущего загруженного трека
    
    // Кэш текущего трека
    fdi_track_light_t current_track;
    bool track_loaded;
    
    // Комментарий (если нужен)
    char comment[64];
    
    // Функции для работы с файлом (должны быть предоставлены пользователем)
    struct {
        void* (*open)(const char *filename);  
        void (*close)(void *handle);
        bool (*seek)(void *handle, uint32_t pos);
        bool (*read)(void *handle, uint8_t *buffer, uint32_t size);
        uint32_t (*tell)(void *handle);
    } file_io;
    
    void *file_handle; // хендл открытого файла
    bool valid;
} fdi_light_ctx_t;

// Результат операций
typedef enum {
    FDI_LIGHT_OK = 0,
    FDI_LIGHT_ERR_INVALID_SIGNATURE,
    FDI_LIGHT_ERR_INVALID_PARAMETERS,
    FDI_LIGHT_ERR_FILE_ERROR,
    FDI_LIGHT_ERR_TRACK_NOT_FOUND
} fdi_light_result_t;

// Функции
fdi_light_result_t fdi_light_open(fdi_light_ctx_t *ctx, const char *filename);
void fdi_light_close(fdi_light_ctx_t *ctx);
fdi_light_result_t fdi_light_load_track(fdi_light_ctx_t *ctx, uint8_t cylinder, uint8_t head);
fdi_track_light_t* fdi_light_get_current_track(fdi_light_ctx_t *ctx);
fdi_sector_light_t* fdi_light_get_sector(fdi_light_ctx_t *ctx, uint8_t sector_r);

bool fdi_light_read_sector_data(fdi_light_ctx_t *ctx, fdi_sector_light_t *sec, uint8_t *buffer);

// Вспомогательная функция
static inline uint16_t fdi_sector_size(uint8_t n) {
    return 128 << (n & 3);
}

#endif // FDI_LIGHT_H